from setuptools import setup

setup(

    name = "paquetecalculos",
    version = "1.0",
    description = "Paquete de calculos",
    author = "Alexander",
    author_email="alexander@principe.com",
    url = "www.alexanderprincipe.com",
    packages = ["calculos", "calculos"]
)